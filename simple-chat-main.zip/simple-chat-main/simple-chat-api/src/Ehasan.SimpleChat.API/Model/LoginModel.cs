﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Ehasan.SimpleChat.API.Model
{
    public class LoginModel
    {
        public string Email { get; set; }
    }
}
