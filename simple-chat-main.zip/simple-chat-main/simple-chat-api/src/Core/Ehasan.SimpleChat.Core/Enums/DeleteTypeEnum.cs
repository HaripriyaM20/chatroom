﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ehasan.SimpleChat.Core.Enums
{
    public enum DeleteTypeEnum
    {
        DeleteForMe,
        DeleteForEveryone
    }
}
